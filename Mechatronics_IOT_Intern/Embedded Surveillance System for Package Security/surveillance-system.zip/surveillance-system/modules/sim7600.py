import serial
import time
import re
from threading import Lock

class SIM7600:
    def __init__(self, port, baudrate=115200):
        self.port = port
        self.baudrate = baudrate
        self.serial = None
        self.lock = Lock()
        
    def connect(self):
        """Initialize serial connection to SIM7600"""
        try:
            self.serial = serial.Serial(
                self.port,
                self.baudrate,
                timeout=1
            )
            time.sleep(2)
            print(f"Connected to SIM7600 on {self.port}")
            
            # Initialize modem
            self.send_at_command("AT")
            self.send_at_command("ATE0")  # Disable echo
            return True
        except Exception as e:
            print(f"Failed to connect to SIM7600: {e}")
            return False
    
    def send_at_command(self, command, timeout=5):
        """Send AT command and return response"""
        with self.lock:
            try:
                self.serial.write((command + "\r\n").encode())
                time.sleep(0.1)
                
                response = ""
                start_time = time.time()
                
                while time.time() - start_time < timeout:
                    if self.serial.in_waiting:
                        response += self.serial.read(self.serial.in_waiting).decode('utf-8', errors='ignore')
                    if "OK" in response or "ERROR" in response:
                        break
                    time.sleep(0.1)
                
                return response.strip()
            except Exception as e:
                print(f"AT command error: {e}")
                return ""
    
    def check_sms(self):
        """Check for incoming SMS messages"""
        try:
            # Set SMS to text mode
            self.send_at_command("AT+CMGF=1")
            
            # List all unread messages
            response = self.send_at_command('AT+CMGL="REC UNREAD"', timeout=10)
            
            messages = []
            if "+CMGL:" in response:
                lines = response.split("\n")
                for i, line in enumerate(lines):
                    if "+CMGL:" in line:
                        # Parse message index and sender
                        match = re.search(r'\+CMGL: (\d+),"[^"]*","([^"]+)"', line)
                        if match and i + 1 < len(lines):
                            index = match.group(1)
                            sender = match.group(2)
                            content = lines[i + 1].strip()
                            messages.append({
                                'index': index,
                                'sender': sender,
                                'content': content
                            })
            
            return messages
        except Exception as e:
            print(f"SMS check error: {e}")
            return []
    
    def delete_sms(self, index):
        """Delete SMS by index"""
        self.send_at_command(f"AT+CMGD={index}")
    
    def send_sms(self, phone_number, message):
        """Send SMS message"""
        try:
            self.send_at_command("AT+CMGF=1")  # Text mode
            self.send_at_command(f'AT+CMGS="{phone_number}"')
            time.sleep(0.5)
            
            with self.lock:
                self.serial.write(message.encode())
                self.serial.write(bytes([26]))  # Ctrl+Z
                time.sleep(2)
            
            print(f"SMS sent to {phone_number}")
            return True
        except Exception as e:
            print(f"SMS send error: {e}")
            return False
    
    def get_gps_data(self):
        """Get GPS coordinates from SIM7600"""
        try:
            # Power on GPS
            self.send_at_command("AT+CGPS=1")
            time.sleep(1)
            
            # Get GPS info
            response = self.send_at_command("AT+CGPSINFO", timeout=5)
            
            # Parse response: +CGPSINFO: lat,N,lon,E,date,time,...
            match = re.search(r'\+CGPSINFO: ([^,]+),([NS]),([^,]+),([EW])', response)
            
            if match and match.group(1) != '':
                lat_str = match.group(1)
                lat_dir = match.group(2)
                lon_str = match.group(3)
                lon_dir = match.group(4)
                
                # Convert DDMM.MMMM to decimal degrees
                lat = self._convert_to_decimal(lat_str, lat_dir)
                lon = self._convert_to_decimal(lon_str, lon_dir)
                
                return {'lat': lat, 'lon': lon}
            else:
                print("GPS fix not available")
                return None
                
        except Exception as e:
            print(f"GPS error: {e}")
            return None
    
    def _convert_to_decimal(self, coord_str, direction):
        """Convert GPS coordinate from DDMM.MMMM to decimal degrees"""
        try:
            # Split degrees and minutes
            if '.' in coord_str:
                parts = coord_str.split('.')
                degrees = float(parts[0][:-2])
                minutes = float(parts[0][-2:] + '.' + parts[1])
                
                decimal = degrees + (minutes / 60.0)
                
                if direction in ['S', 'W']:
                    decimal = -decimal
                
                return round(decimal, 6)
        except:
            return 0.0
    
    def setup_internet(self, apn="internet"):
        """Setup LTE internet connection"""
        try:
            print("Setting up LTE internet connection...")
            
            # Check network registration
            response = self.send_at_command("AT+CREG?", timeout=5)
            print(f"Network registration: {response}")
            
            # Check if already registered (0,1 = registered home, 0,5 = registered roaming)
            if "+CREG: 0,1" not in response and "+CREG: 0,5" not in response:
                print("Waiting for network registration...")
                time.sleep(5)
                response = self.send_at_command("AT+CREG?", timeout=5)
                print(f"Network registration retry: {response}")
            
            # Configure APN for context 1
            self.send_at_command(f'AT+CGDCONT=1,"IP","{apn}"')
            time.sleep(1)
            
            # Deactivate first (in case it was active)
            self.send_at_command("AT+CGACT=0,1", timeout=5)
            time.sleep(1)
            
            # Activate PDP context
            response = self.send_at_command("AT+CGACT=1,1", timeout=15)
            print(f"PDP activation: {response}")
            
            time.sleep(2)
            
            # Check IP address - this is the primary indicator
            response = self.send_at_command("AT+CGPADDR=1", timeout=5)
            print(f"IP Address (CGPADDR): {response}")
            
            # Extract and validate IP address
            if "+CGPADDR" in response:
                # Try with quotes first
                match = re.search(r'\+CGPADDR: 1,"?([0-9.]+)"?', response)
                if match:
                    ip = match.group(1)
                    if ip != "0.0.0.0" and ip != "":
                        print(f"✓ LTE internet connected - IP: {ip}")
                        return True
            
            print("✗ Failed to establish internet connection")
            return False
                
        except Exception as e:
            print(f"Internet setup error: {e}")
            return False
    
    def check_internet_connection(self):
        """Check if internet is connected"""
        try:
            response = self.send_at_command("AT+CGPADDR=1", timeout=3)
            if "+CGPADDR" in response:
                match = re.search(r'\+CGPADDR: 1,"?([0-9.]+)"?', response)
                if match:
                    ip = match.group(1)
                    return ip != "0.0.0.0" and ip != ""
            return False
        except:
            return False
    
    def get_signal_strength(self):
        """Get signal strength"""
        try:
            response = self.send_at_command("AT+CSQ")
            match = re.search(r'\+CSQ: (\d+),', response)
            if match:
                rssi = int(match.group(1))
                if rssi == 99:
                    return "No signal"
                else:
                    # Convert to dBm (approximate)
                    dbm = -113 + (rssi * 2)
                    return f"{rssi} ({dbm} dBm)"
            return "Unknown"
        except:
            return "Error"
    
    def close(self):
        """Close serial connection"""
        if self.serial:
            self.serial.close()

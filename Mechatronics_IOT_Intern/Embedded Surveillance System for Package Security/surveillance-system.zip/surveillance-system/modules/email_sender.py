import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from datetime import datetime
import os

class EmailSender:
    def __init__(self, smtp_server, smtp_port, sender_email, sender_password):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.sender_email = sender_email
        self.sender_password = sender_password
        
    def send_alert_email(self, recipient_email, lat, lon, image_path, subject="Theft Alert"):
        """Send email with location link and attached image"""
        try:
            # Create message
            msg = MIMEMultipart('related')
            msg['From'] = self.sender_email
            msg['To'] = recipient_email
            msg['Subject'] = subject
            
            # Google Maps link
            maps_link = f"https://www.google.com/maps?q={lat},{lon}"
            
            # Create HTML body
            html_body = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            background-color: #f4f4f4;
                            padding: 20px;
                        }}
                        .container {{
                            background-color: white;
                            padding: 30px;
                            border-radius: 10px;
                            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                            max-width: 600px;
                            margin: 0 auto;
                        }}
                        .alert {{
                            background-color: #f8d7da;
                            color: #721c24;
                            padding: 15px;
                            border-radius: 5px;
                            margin-bottom: 20px;
                            font-weight: bold;
                            text-align: center;
                            font-size: 18px;
                        }}
                        .info {{
                            background-color: #e7f3ff;
                            padding: 15px;
                            border-radius: 5px;
                            margin: 15px 0;
                        }}
                        .location-btn {{
                            display: inline-block;
                            background-color: #4285f4;
                            color: white;
                            padding: 12px 30px;
                            text-decoration: none;
                            border-radius: 5px;
                            font-weight: bold;
                            margin: 20px 0;
                        }}
                        .location-btn:hover {{
                            background-color: #357ae8;
                        }}
                        .image-container {{
                            text-align: center;
                            margin: 20px 0;
                        }}
                        .image-container img {{
                            max-width: 100%;
                            height: auto;
                            border-radius: 5px;
                            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
                        }}
                        .footer {{
                            text-align: center;
                            color: #666;
                            font-size: 12px;
                            margin-top: 20px;
                            padding-top: 20px;
                            border-top: 1px solid #ddd;
                        }}
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="alert">
                            🚨 PACKAGE THEFT DETECTED
                        </div>
                        
                        <div class="info">
                            <strong>⏰ Time:</strong> {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}<br>
                            <strong>📍 Coordinates:</strong> {lat:.6f}, {lon:.6f}
                        </div>
                        
                        <div style="text-align: center;">
                            <a href="{maps_link}" class="location-btn">
                                📍 VIEW LOCATION ON GOOGLE MAPS
                            </a>
                        </div>
                        
                        <div class="image-container">
                            <h3>📷 Camera Snapshot</h3>
                            <img src="cid:camera_image" alt="Camera snapshot">
                        </div>
                        
                        <div class="footer">
                            Package Surveillance System<br>
                            Raspberry Pi 4 with SIM7600X
                        </div>
                    </div>
                </body>
            </html>
            """
            
            # Attach HTML body
            msg_alternative = MIMEMultipart('alternative')
            msg.attach(msg_alternative)
            
            # Plain text version
            text_body = f"""
PACKAGE THEFT ALERT

Time: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Location: {lat:.6f}, {lon:.6f}

View on Google Maps: {maps_link}

Camera snapshot attached.

---
Package Surveillance System
            """
            
            msg_alternative.attach(MIMEText(text_body, 'plain'))
            msg_alternative.attach(MIMEText(html_body, 'html'))
            
            # Attach image
            if os.path.exists(image_path):
                with open(image_path, 'rb') as f:
                    img_data = f.read()
                    image = MIMEImage(img_data, name=os.path.basename(image_path))
                    image.add_header('Content-ID', '<camera_image>')
                    image.add_header('Content-Disposition', 'inline', filename=os.path.basename(image_path))
                    msg.attach(image)
            
            # Send email
            print(f"Connecting to {self.smtp_server}:{self.smtp_port}...")
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                server.send_message(msg)
            
            print(f"✓ Email sent to {recipient_email}")
            return True
            
        except Exception as e:
            print(f"Email send error: {e}")
            return False
    
    def send_status_email(self, recipient_email, status, lat=None, lon=None):
        """Send status update email"""
        try:
            msg = MIMEMultipart()
            msg['From'] = self.sender_email
            msg['To'] = recipient_email
            msg['Subject'] = f"Package System Status: {status}"
            
            maps_link = ""
            if lat and lon:
                maps_link = f"\n\nCurrent Location: https://www.google.com/maps?q={lat},{lon}"
            
            body = f"""
Package Surveillance System Status Update

Status: {status}
Time: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}{maps_link}

---
Package Surveillance System
            """
            
            msg.attach(MIMEText(body, 'plain'))
            
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                server.send_message(msg)
            
            print(f"✓ Status email sent to {recipient_email}")
            return True
            
        except Exception as e:
            print(f"Status email error: {e}")
            return False

import RPi.GPIO as GPIO
import time
import threading

class LEDController:
    def __init__(self, white_led_pin, blue_led_pin):
        self.white_led = white_led_pin
        self.blue_led = blue_led_pin
        self.blink_thread = None
        self.blinking = False
        
        # Setup GPIO
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.white_led, GPIO.OUT)
        GPIO.setup(self.blue_led, GPIO.OUT)
        
        # Turn off both LEDs initially
        GPIO.output(self.white_led, GPIO.LOW)
        GPIO.output(self.blue_led, GPIO.LOW)
    
    def white_on(self):
        """Turn white LED on (system armed)"""
        GPIO.output(self.white_led, GPIO.HIGH)
        print("White LED ON - System Armed")
    
    def white_off(self):
        """Turn white LED off"""
        GPIO.output(self.white_led, GPIO.LOW)
        print("White LED OFF")
    
    def blue_on(self):
        """Turn blue LED on (theft detected)"""
        GPIO.output(self.blue_led, GPIO.HIGH)
        print("Blue LED ON - Theft Detected")
    
    def blue_off(self):
        """Turn blue LED off"""
        GPIO.output(self.blue_led, GPIO.LOW)
        print("Blue LED OFF")
    
    def blue_blink(self, interval=0.5):
        """Blink blue LED"""
        self.stop_blink()
        self.blinking = True
        self.blink_thread = threading.Thread(
            target=self._blink_loop,
            args=(self.blue_led, interval),
            daemon=True
        )
        self.blink_thread.start()
    
    def _blink_loop(self, pin, interval):
        """Blink loop"""
        while self.blinking:
            GPIO.output(pin, GPIO.HIGH)
            time.sleep(interval)
            GPIO.output(pin, GPIO.LOW)
            time.sleep(interval)
    
    def stop_blink(self):
        """Stop blinking"""
        self.blinking = False
        if self.blink_thread:
            self.blink_thread.join(timeout=2)
    
    def all_off(self):
        """Turn off all LEDs"""
        self.stop_blink()
        self.white_off()
        self.blue_off()
    
    def cleanup(self):
        """Cleanup GPIO"""
        self.all_off()
        GPIO.cleanup([self.white_led, self.blue_led])

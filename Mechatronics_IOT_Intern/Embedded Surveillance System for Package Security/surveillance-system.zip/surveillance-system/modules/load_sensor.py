import RPi.GPIO as GPIO
import time

class LoadSensor:
    def __init__(self, gpio_pin, callback=None):
        self.gpio_pin = gpio_pin
        self.callback = callback
        self.triggered = False
        
        # Setup GPIO
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.gpio_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
        
    def setup_interrupt(self):
        """Setup GPIO interrupt for load sensor"""
        try:
            GPIO.add_event_detect(
                self.gpio_pin,
                GPIO.FALLING,  # Trigger on falling edge
                callback=self._interrupt_handler,
                bouncetime=300  # 300ms debounce
            )
            print(f"Load sensor interrupt configured on GPIO{self.gpio_pin}")
        except Exception as e:
            print(f"Failed to setup interrupt: {e}")
    
    def _interrupt_handler(self, channel):
        """Handle interrupt from load sensor"""
        print("⚠️  LOAD SENSOR TRIGGERED - Package lifted!")
        self.triggered = True
        
        if self.callback:
            self.callback()
    
    def reset(self):
        """Reset trigger state"""
        self.triggered = False
    
    def is_triggered(self):
        """Check if sensor was triggered"""
        return self.triggered
    
    def cleanup(self):
        """Cleanup GPIO"""
        GPIO.cleanup(self.gpio_pin)

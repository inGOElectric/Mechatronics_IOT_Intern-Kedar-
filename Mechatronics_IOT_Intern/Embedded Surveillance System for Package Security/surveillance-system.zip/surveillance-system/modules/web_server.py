from flask import Flask, jsonify, send_from_directory, render_template_string
import threading
import os
import time

class WebServer:
    def __init__(self, image_dir, host='0.0.0.0', port=5000):
        self.app = Flask(__name__)
        self.image_dir = image_dir
        self.host = host
        self.port = port
        self.status = "IDLE"
        self.gps_lat = 0.0
        self.gps_lon = 0.0
        self.setup_routes()
    
    def setup_routes(self):
        @self.app.route('/')
        def index():
            return render_template_string(TRACKING_HTML)
        
        @self.app.route('/api/status')
        def get_status():
            return jsonify({
                'status': self.status,
                'timestamp': time.time()
            })
        
        @self.app.route('/api/gps')
        def get_gps():
            return jsonify({
                'lat': self.gps_lat,
                'lon': self.gps_lon,
                'timestamp': time.time()
            })
        
        @self.app.route('/api/images')
        def get_images():
            images = sorted([f for f in os.listdir(self.image_dir) if f.endswith('.jpg')], reverse=True)
            return jsonify({'images': images[:10]})
        
        @self.app.route('/image/<filename>')
        def get_image(filename):
            return send_from_directory(self.image_dir, filename)
    
    def start(self):
        thread = threading.Thread(target=self._run, daemon=True)
        thread.start()
        print(f"Web server started on http://{self.host}:{self.port}")
    
    def _run(self):
        self.app.run(host=self.host, port=self.port, debug=False, use_reloader=False)
    
    def update_status(self, status):
        self.status = status
    
    def update_gps(self, lat, lon):
        self.gps_lat = lat
        self.gps_lon = lon

# Enhanced HTML with auto-refresh and OpenStreetMap (no API key needed!)
TRACKING_HTML = '''
<!DOCTYPE html>
<html>
<head>
    <title>📦 Package Tracker - Live</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .header {
            background: white;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        .header h1 {
            font-size: 2.5em;
            color: #333;
            margin-bottom: 10px;
        }
        .status {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 25px;
            font-weight: bold;
            font-size: 1.1em;
        }
        .status.ARMED { background: #ffd93d; color: #333; }
        .status.THEFT_DETECTED { background: #ff6b6b; color: white; animation: pulse 1s infinite; }
        .status.IDLE { background: #95e1d3; color: #333; }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }
        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        @media (max-width: 768px) {
            .grid { grid-template-columns: 1fr; }
        }
        .card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        .card h2 {
            color: #667eea;
            margin-bottom: 15px;
            font-size: 1.5em;
        }
        #map {
            width: 100%;
            height: 400px;
            border-radius: 15px;
            background: #f0f0f0;
        }
        .camera-feed {
            width: 100%;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        }
        .coords {
            font-size: 1.2em;
            color: #333;
            margin: 10px 0;
            font-family: 'Courier New', monospace;
        }
        .timestamp {
            color: #999;
            font-size: 0.9em;
            margin-top: 10px;
        }
        .live-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            background: #4caf50;
            border-radius: 50%;
            margin-right: 8px;
            animation: blink 2s infinite;
        }
        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.3; }
        }
        .map-link {
            display: inline-block;
            margin-top: 10px;
            padding: 12px 24px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 25px;
            font-weight: bold;
            transition: transform 0.2s;
        }
        .map-link:hover {
            transform: scale(1.05);
        }
        .refresh-info {
            background: #f0f0f0;
            padding: 10px;
            border-radius: 10px;
            margin-top: 10px;
            font-size: 0.9em;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📦 Package Tracker</h1>
            <div>
                <span class="live-indicator"></span>
                <span class="status" id="status">Loading...</span>
                <span class="timestamp" id="lastUpdate"></span>
            </div>
        </div>
        
        <div class="grid">
            <div class="card">
                <h2>📍 Live Location</h2>
                <div id="map"></div>
                <div class="coords" id="coords">Waiting for GPS...</div>
                <a href="#" id="mapLink" class="map-link" target="_blank">Open in Google Maps</a>
                <div class="refresh-info">🔄 GPS updates every 5 seconds</div>
            </div>
            
            <div class="card">
                <h2>📷 Live Camera</h2>
                <img src="/image/latest.jpg" class="camera-feed" id="cameraFeed" alt="Camera Feed">
                <div class="timestamp" id="imageTime"></div>
                <div class="refresh-info">🔄 Image updates every 10 seconds</div>
            </div>
        </div>
    </div>

    <script>
        let map, marker;
        
        // Initialize map with OpenStreetMap (no API key needed!)
        function initMap() {
            const defaultPos = [15.3647, 75.1240];
            map = L.map('map').setView(defaultPos, 15);
            
            // Add OpenStreetMap tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 19
            }).addTo(map);
            
            // Add marker
            marker = L.marker(defaultPos).addTo(map);
            marker.bindPopup('📦 Package Location').openPopup();
        }
        
        // Update status
        async function updateStatus() {
            try {
                const response = await fetch('/api/status');
                const data = await response.json();
                const statusEl = document.getElementById('status');
                statusEl.textContent = data.status.replace('_', ' ');
                statusEl.className = 'status ' + data.status;
            } catch (error) {
                console.error('Status update failed:', error);
            }
        }
        
        // Update GPS (every 5 seconds)
        async function updateGPS() {
            try {
                const response = await fetch('/api/gps');
                const data = await response.json();
                
                if (data.lat !== 0 && data.lon !== 0) {
                    const pos = [data.lat, data.lon];
                    marker.setLatLng(pos);
                    map.setView(pos, map.getZoom());
                    
                    document.getElementById('coords').textContent = 
                        `${data.lat.toFixed(6)}, ${data.lon.toFixed(6)}`;
                    document.getElementById('mapLink').href = 
                        `https://www.google.com/maps?q=${data.lat},${data.lon}`;
                    
                    const time = new Date(data.timestamp * 1000).toLocaleTimeString();
                    document.getElementById('lastUpdate').textContent = `Updated: ${time}`;
                }
            } catch (error) {
                console.error('GPS update failed:', error);
            }
        }
        
        // Update camera image (every 10 seconds)
        function updateCamera() {
            const img = document.getElementById('cameraFeed');
            img.src = '/image/latest.jpg?' + new Date().getTime();
            const time = new Date().toLocaleTimeString();
            document.getElementById('imageTime').textContent = `Updated: ${time}`;
        }
        
        // Start updates
        window.onload = function() {
            initMap();
            updateStatus();
            updateGPS();
            updateCamera();
            
            setInterval(updateStatus, 5000);   // Status every 5s
            setInterval(updateGPS, 5000);      // GPS every 5s
            setInterval(updateCamera, 10000);  // Camera every 10s
        };
    </script>
</body>
</html>
'''

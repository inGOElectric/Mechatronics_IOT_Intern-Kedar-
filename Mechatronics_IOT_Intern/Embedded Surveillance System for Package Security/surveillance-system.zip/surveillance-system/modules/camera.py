import os
import time
import threading
from datetime import datetime
from pathlib import Path

class CameraController:
    def __init__(self, image_dir, width=1280, height=720, interval=10, max_images=100):
        self.image_dir = image_dir
        self.width = width
        self.height = height
        self.interval = interval
        self.max_images = max_images
        self.running = False
        self.thread = None
        
        # Create image directory if it doesn't exist
        Path(self.image_dir).mkdir(parents=True, exist_ok=True)
        
    def start_capture(self):
        """Start continuous camera capture"""
        if not self.running:
            self.running = True
            self.thread = threading.Thread(target=self._capture_loop, daemon=True)
            self.thread.start()
            print("Camera capture started")
    
    def stop_capture(self):
        """Stop camera capture"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
        print("Camera capture stopped")
    
    def _capture_loop(self):
        """Continuous capture loop"""
        while self.running:
            try:
                self.capture_image()
                self._cleanup_old_images()
                time.sleep(self.interval)
            except Exception as e:
                print(f"Camera capture error: {e}")
                time.sleep(5)
    
    def capture_image(self):
        """Capture a single image with timestamp"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            timestamped_path = os.path.join(self.image_dir, f"img_{timestamp}.jpg")
            latest_path = os.path.join(self.image_dir, "latest.jpg")
            
            # Capture to timestamped file
            cmd = (f"rpicam-still -o {timestamped_path} "
                   f"--width {self.width} --height {self.height} "
                   f"--nopreview -t 1")
            
            result = os.system(cmd)
            
            if result == 0:
                # Copy to latest.jpg (always same filename for easy access)
                os.system(f"cp {timestamped_path} {latest_path}")
                print(f"Image captured: {timestamp}")
                return True
            else:
                print("Camera capture failed")
                return False
                
        except Exception as e:
            print(f"Camera error: {e}")
            return False
    
    def _cleanup_old_images(self):
        """Keep only the last MAX_IMAGES images"""
        try:
            # Get all timestamped images (not latest.jpg)
            images = sorted([
                f for f in os.listdir(self.image_dir) 
                if f.startswith("img_") and f.endswith(".jpg")
            ])
            
            # Delete oldest images if we exceed max
            while len(images) > self.max_images:
                oldest = images.pop(0)
                os.remove(os.path.join(self.image_dir, oldest))
                print(f"Deleted old image: {oldest}")
                
        except Exception as e:
            print(f"Cleanup error: {e}")
    
    def get_image_list(self):
        """Get list of all stored images"""
        try:
            images = sorted([
                f for f in os.listdir(self.image_dir) 
                if f.startswith("img_") and f.endswith(".jpg")
            ], reverse=True)
            return images
        except:
            return []
    
    def test_camera(self):
        """Test camera functionality"""
        print("Testing camera...")
        return self.capture_image()

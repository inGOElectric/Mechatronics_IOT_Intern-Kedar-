import socket

# Hardware Configuration
GPIO_LOAD_SENSOR = 17
GPIO_WHITE_LED = 23
GPIO_BLUE_LED = 24

# I2C Configuration
I2C_SDA = 2
I2C_SCL = 3

# SIM7600 Configuration
SIM7600_PORT = "/dev/ttyUSB2"  # Adjust based on your system (check with: ls /dev/ttyUSB*)
SIM7600_BAUDRATE = 115200
SIM_APN = "internet"  # Check with your carrier (common: "internet", "hologram", "iot.1nce.net")
OWNER_PHONE = "+916362925660"  # Replace with your phone number

# Camera Configuration
IMAGE_DIR = "/home/user1234/surveillance-system/images"
LATEST_IMAGE = "latest.jpg"
MAX_IMAGES = 100  # Keep last 100 images
CAPTURE_INTERVAL = 10  # seconds
IMAGE_WIDTH = 1280
IMAGE_HEIGHT = 720

# GPS Configuration
GPS_UPDATE_INTERVAL = 30  # seconds

# Web Server Configuration
WEB_HOST = "0.0.0.0"
WEB_PORT = 5000

# Email Configuration
EMAIL_ENABLED = True
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SENDER_EMAIL = "kedar302004@gmail.com"  # Replace with your Gmail
SENDER_PASSWORD = "fsgqqdyvjyvfcrav"  # Replace with Gmail App Password
RECIPIENT_EMAIL = "kedareshwar999@gmail.com"  # Replace with recipient email
EMAIL_SUBJECT = "🚨 PACKAGE THEFT ALERT"

# System States
STATE_IDLE = "IDLE"
STATE_ARMED = "ARMED"
STATE_THEFT_DETECTED = "THEFT_DETECTED"

# Get Raspberry Pi IP for SMS links
def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "localhost"

LOCAL_IP = get_local_ip()
TRACKING_URL = f"http://{LOCAL_IP}:{WEB_PORT}"
IMAGE_URL = f"http://{LOCAL_IP}:{WEB_PORT}/image/latest"

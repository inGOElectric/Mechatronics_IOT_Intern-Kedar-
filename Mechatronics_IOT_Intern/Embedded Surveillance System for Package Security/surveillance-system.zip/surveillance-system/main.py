#!/usr/bin/env python3
import time
import signal
import sys
from datetime import datetime
import os

# Import configuration
import config

# Import modules
from modules.sim7600 import SIM7600
from modules.camera import CameraController
from modules.load_sensor import LoadSensor
from modules.led_controller import LEDController
from modules.web_server import WebServer
from modules.email_sender import EmailSender

class SurveillanceSystem:
    def __init__(self):
        self.state = config.STATE_IDLE
        self.running = True
        self.last_gps = {'lat': 0.0, 'lon': 0.0}
        
        # Initialize components
        print("Initializing Surveillance System...")
        
        self.led = LEDController(config.GPIO_WHITE_LED, config.GPIO_BLUE_LED)
        self.camera = CameraController(
            config.IMAGE_DIR,
            config.IMAGE_WIDTH,
            config.IMAGE_HEIGHT,
            config.CAPTURE_INTERVAL,
            config.MAX_IMAGES
        )
        self.load_sensor = LoadSensor(config.GPIO_LOAD_SENSOR, self.on_theft_detected)
        self.sim7600 = SIM7600(config.SIM7600_PORT, config.SIM7600_BAUDRATE)
        self.web_server = WebServer(config.IMAGE_DIR, config.WEB_HOST, config.WEB_PORT)
        
        # Initialize email sender if enabled
        if config.EMAIL_ENABLED:
            self.email_sender = EmailSender(
                config.SMTP_SERVER,
                config.SMTP_PORT,
                config.SENDER_EMAIL,
                config.SENDER_PASSWORD
            )
        else:
            self.email_sender = None
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self.shutdown)
        signal.signal(signal.SIGTERM, self.shutdown)
    
    def start(self):
        """Start the surveillance system"""
        print("\n" + "="*50)
        print("📦 PACKAGE SURVEILLANCE SYSTEM")
        print("="*50)
        
        # Start web server
        self.web_server.start()
        print(f"🌐 Tracking URL: {config.TRACKING_URL}")
        print(f"📷 Image URL: {config.IMAGE_URL}")
        
        # Connect to SIM7600
        if self.sim7600.connect():
            print("✓ SIM7600 connected")
            
            # Setup internet connection
            print("\n📡 Setting up LTE internet...")
            if self.sim7600.setup_internet(config.SIM_APN):
                print("✓ Internet connected")
                signal_strength = self.sim7600.get_signal_strength()
                print(f"📶 Signal strength: {signal_strength}")
            else:
                print("⚠️  Warning: Internet connection failed")
        else:
            print("⚠️  Warning: SIM7600 not connected. SMS, GPS, and Email disabled.")
        
        # Setup load sensor interrupt
        self.load_sensor.setup_interrupt()
        
        # Test camera
        print("\n📸 Testing camera...")
        if self.camera.test_camera():
            print("✓ Camera working")
        else:
            print("✗ Camera test failed")
        
        print("\n💡 System ready. Waiting for 'READY' SMS command...")
        print("="*50 + "\n")
        print("🔧 AUTO-ARMING SYSTEM FOR TESTING...")
        time.sleep(2)
        self.arm_system()

        # Main loop
        self.main_loop()
    
    def main_loop(self):
        """Main system loop"""
        last_sms_check = 0
        last_gps_update = 0
        
        while self.running:
            try:
                current_time = time.time()
                
                # Check for SMS commands every 5 seconds
                if current_time - last_sms_check > 5:
                    self.check_sms_commands()
                    last_sms_check = current_time
                
                # Update GPS every GPS_UPDATE_INTERVAL seconds
                if self.state != config.STATE_IDLE and current_time - last_gps_update > config.GPS_UPDATE_INTERVAL:
                    self.update_gps()
                    last_gps_update = current_time
                
                time.sleep(1)
                
            except Exception as e:
                print(f"Main loop error: {e}")
                time.sleep(5)
    
    def check_sms_commands(self):
        """Check for incoming SMS commands"""
        try:
            messages = self.sim7600.check_sms()
            
            for msg in messages:
                content = msg['content'].strip().upper()
                sender = msg['sender']
                
                print(f"📨 SMS from {sender}: {content}")
                
                if content == "READY":
                    self.arm_system()
                elif content == "DISARM":
                    self.disarm_system()
                elif content == "STATUS":
                    self.send_status_sms(sender)
                
                # Delete processed message
                self.sim7600.delete_sms(msg['index'])
                
        except Exception as e:
            print(f"SMS check error: {e}")
    
    def arm_system(self):
        """Arm the surveillance system"""
        if self.state == config.STATE_IDLE:
            print("\n🔒 SYSTEM ARMED")
            self.state = config.STATE_ARMED
            self.led.white_on()
            self.web_server.update_status(self.state)
            
            # Send confirmation SMS
            self.sim7600.send_sms(
                config.OWNER_PHONE,
                f"System ARMED.\nView: http://100.116.112.37:5000"
            )
    
    def disarm_system(self):
        """Disarm the surveillance system"""
        print("\n🔓 SYSTEM DISARMED")
        self.state = config.STATE_IDLE
        self.led.all_off()
        self.camera.stop_capture()
        self.load_sensor.reset()
        self.web_server.update_status(self.state)
        
        # Send confirmation SMS
        self.sim7600.send_sms(
            config.OWNER_PHONE,
            "System DISARMED."
        )
    
    def on_theft_detected(self):
        """Callback when load sensor detects theft"""
        if self.state == config.STATE_ARMED:
            print("\n🚨 THEFT DETECTED!")
            self.state = config.STATE_THEFT_DETECTED
            self.led.blue_on()
            self.web_server.update_status(self.state)
            
            # Start camera capture
            self.camera.start_capture()
            
            # Wait a moment for first image to be captured
            time.sleep(2)
            
            # Get current GPS
            gps_data = self.sim7600.get_gps_data()
            if gps_data:
                self.last_gps = gps_data
                lat, lon = gps_data['lat'], gps_data['lon']
            else:
                lat, lon = self.last_gps['lat'], self.last_gps['lon']
            
            # Send alert SMS
            alert_msg = (
                f"⚠️ THEFT ALERT!\n"
                f"Package lifted at {datetime.now().strftime('%H:%M:%S')}\n"
                f"Location: https://www.google.com/maps?q={lat},{lon}\n"
                f"View: http://100.116.112.37:5000"
            )
            self.sim7600.send_sms(config.OWNER_PHONE, alert_msg)
            
            # Send email with photo and location
            if self.email_sender and config.EMAIL_ENABLED:
                print("📧 Sending alert email...")
                image_path = os.path.join(config.IMAGE_DIR, "latest.jpg")
                
                if os.path.exists(image_path):
                    self.email_sender.send_alert_email(
                        config.RECIPIENT_EMAIL,
                        lat,
                        lon,
                        image_path,
                        config.EMAIL_SUBJECT
                    )
                else:
                    print("⚠️  No image available for email")
    
    def update_gps(self):
        """Update GPS coordinates"""
        try:
            gps_data = self.sim7600.get_gps_data()
            if gps_data:
                self.last_gps = gps_data
                self.web_server.update_gps(gps_data['lat'], gps_data['lon'])
                print(f"📍 GPS: {gps_data['lat']}, {gps_data['lon']}")
        except Exception as e:
            print(f"GPS update error: {e}")
    
    def send_status_sms(self, phone):
        """Send status SMS"""
        status_msg = (
            f"Status: {self.state}\n"
            f"Track: {config.TRACKING_URL}"
        )
        self.sim7600.send_sms(phone, status_msg)
    
    def shutdown(self, signum=None, frame=None):
        """Graceful shutdown"""
        print("\n\n🛑 Shutting down...")
        self.running = False
        
        self.camera.stop_capture()
        self.led.cleanup()
        self.load_sensor.cleanup()
        self.sim7600.close()
        
        print("✓ Cleanup complete")
        sys.exit(0)

if __name__ == "__main__":
    system = SurveillanceSystem()
    system.start()
